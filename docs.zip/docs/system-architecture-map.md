# Business AI Assistant - Complete System Architecture Map

## 🎯 High-Level System Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         BUSINESS AI ASSISTANT                           │
│                    Multi-Tenant RAG-Powered System                      │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    ▼                               ▼
        ┌────────────────────┐          ┌────────────────────┐
        │   BUSINESS PORTAL  │          │   PUBLIC CHAT      │
        │  (Authenticated)   │          │   (Anonymous)      │
        └────────────────────┘          └────────────────────┘
```

---

## 📋 Complete Technology Stack

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            TECHNOLOGY LAYERS                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  🎨 FRONTEND (Not part of API, but connects to it)                     │
│  ├─ React / Vue / Plain HTML + JavaScript                              │
│  ├─ Chat Widget (embeddable)                                           │
│  └─ Business Dashboard                                                 │
│                                                                         │
│  🔧 BACKEND FRAMEWORK                                                   │
│  ├─ Node.js (Runtime)                                                  │
│  ├─ Express.js (Web Framework)                                         │
│  └─ JavaScript/ES6+                                                    │
│                                                                         │
│  💾 DATABASES                                                           │
│  ├─ MongoDB (User, Business, Documents metadata)                       │
│  ├─ ChromaDB (Vector embeddings for semantic search)                   │
│  └─ In-Memory (Redis - optional for caching)                          │
│                                                                         │
│  🤖 AI/ML SERVICES                                                      │
│  ├─ OpenAI API                                                         │
│  │   ├─ text-embedding-3-small (Embeddings)                           │
│  │   └─ gpt-3.5-turbo (Chat completions)                              │
│  └─ Vector Search (ChromaDB)                                           │
│                                                                         │
│  🔐 SECURITY & MIDDLEWARE                                               │
│  ├─ JWT (jsonwebtoken) - Authentication                                │
│  ├─ bcrypt - Password hashing                                          │
│  ├─ Helmet - Security headers                                          │
│  ├─ CORS - Cross-origin control                                        │
│  ├─ express-rate-limit - Rate limiting                                 │
│  ├─ express-mongo-sanitize - NoSQL injection prevention                │
│  ├─ express-validator - Input validation                               │
│  └─ xss-clean - XSS attack prevention                                  │
│                                                                         │
│  📁 FILE PROCESSING                                                     │
│  ├─ Multer (File uploads)                                              │
│  ├─ pdf-parse (PDF text extraction)                                    │
│  ├─ mammoth (DOCX text extraction)                                     │
│  └─ csv-parser (CSV processing)                                        │
│                                                                         │
│  🛠️ UTILITIES                                                           │
│  ├─ dotenv (Environment variables)                                     │
│  ├─ Morgan/Winston (Logging)                                           │
│  └─ Nodemon (Development)                                              │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🏗️ Detailed System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                   CLIENTS                                       │
├────────────────────────────────┬────────────────────────────────────────────────┤
│                                │                                                │
│  👥 BUSINESS USERS             │  👤 END CUSTOMERS                              │
│  (Admin Dashboard)             │  (Public Chat Widget)                          │
│  - Business Owners             │  - Website Visitors                            │
│  - Team Members                │  - No Registration                             │
│  - Authenticated               │  - Anonymous                                   │
│                                │                                                │
└────────────┬───────────────────┴────────────────┬───────────────────────────────┘
             │                                    │
             │ HTTPS                              │ HTTPS
             │ JWT Token                          │ Session ID
             │                                    │
             ▼                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            🔒 SECURITY LAYER                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐ │
│  │   CORS Filter        │  │   Rate Limiter       │  │   Helmet Headers     │ │
│  │   ✓ Allowed origins  │  │   ✓ IP-based limits  │  │   ✓ XSS protection   │ │
│  │   ✓ Credentials      │  │   ✓ Per-endpoint     │  │   ✓ CSP headers      │ │
│  └──────────────────────┘  └──────────────────────┘  └──────────────────────┘ │
│                                                                                 │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐ │
│  │   Input Validation   │  │   Sanitization       │  │   File Validation    │ │
│  │   ✓ Schema checks    │  │   ✓ NoSQL injection  │  │   ✓ MIME type        │ │
│  │   ✓ Type validation  │  │   ✓ XSS cleaning     │  │   ✓ File size        │ │
│  └──────────────────────┘  └──────────────────────┘  └──────────────────────┘ │
│                                                                                 │
└─────────────────────────────────┬───────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          🎯 EXPRESS.JS API SERVER                               │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        AUTHENTICATION MIDDLEWARE                        │   │
│  │  ┌────────────────────────────────────────────────────────────────┐    │   │
│  │  │  JWT Verification → Business Access Check → Permission Check  │    │   │
│  │  └────────────────────────────────────────────────────────────────┘    │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                             API ROUTES                                  │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  📌 PUBLIC ROUTES (No Auth)                                            │   │
│  │  ├─ GET  /api/public/:businessSlug                                     │   │
│  │  │       → Get business info for chat widget                           │   │
│  │  │                                                                      │   │
│  │  └─ POST /api/public/:businessSlug/chat                                │   │
│  │          → Customer asks question (RAG)                                │   │
│  │          Security: IP-based rate limit (10/hour)                       │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  🔐 BUSINESS AUTH ROUTES                                               │   │
│  │  ├─ POST /api/business/register                                        │   │
│  │  │       → Register new business + owner                               │   │
│  │  │       Security: Email validation, password strength                 │   │
│  │  │                                                                      │   │
│  │  └─ POST /api/business/login                                           │   │
│  │          → Business user login                                         │   │
│  │          Security: Rate limit (5 attempts/15min), bcrypt verify        │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  📄 DOCUMENT ROUTES (Auth Required)                                    │   │
│  │  ├─ POST /api/business/:businessId/documents/upload                    │   │
│  │  │       → Upload business document                                    │   │
│  │  │       Security: JWT + Permission + File validation                  │   │
│  │  │                                                                      │   │
│  │  ├─ GET  /api/business/:businessId/documents                           │   │
│  │  │       → List all business documents                                 │   │
│  │  │       Security: JWT + Business access check                         │   │
│  │  │                                                                      │   │
│  │  └─ DELETE /api/business/:businessId/documents/:docId                  │   │
│  │          → Delete document                                             │   │
│  │          Security: JWT + Permission check + Ownership                  │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  👥 TEAM ROUTES (Auth Required)                                        │   │
│  │  ├─ POST /api/business/:businessId/team/invite                         │   │
│  │  │       → Invite team member                                          │   │
│  │  │       Security: JWT + Admin/Owner only                              │   │
│  │  │                                                                      │   │
│  │  ├─ GET  /api/business/:businessId/team                                │   │
│  │  │       → List team members                                           │   │
│  │  │                                                                      │   │
│  │  ├─ PATCH /api/business/:businessId/team/:userId                       │   │
│  │  │       → Update member role/permissions                              │   │
│  │  │                                                                      │   │
│  │  └─ DELETE /api/business/:businessId/team/:userId                      │   │
│  │          → Remove team member                                          │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  📊 ANALYTICS ROUTES (Auth Required)                                   │   │
│  │  └─ GET  /api/business/:businessId/analytics                           │   │
│  │          → Get chat statistics and insights                            │   │
│  │          Security: JWT + Business access                               │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  ⚙️ SETTINGS ROUTES (Auth Required)                                    │   │
│  │  └─ PATCH /api/business/:businessId/settings                           │   │
│  │          → Update business/chat settings                               │   │
│  │          Security: JWT + Owner/Admin only                              │   │
│  │                                                                         │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                         │   │
│  │  🏥 HEALTH CHECK                                                       │   │
│  │  └─ GET  /api/health                                                   │   │
│  │          → System health status                                        │   │
│  │                                                                         │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
└─────────────────────────────────┬───────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          🎯 BUSINESS LOGIC LAYER                                │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                            CONTROLLERS                                   │  │
│  ├──────────────────────────────────────────────────────────────────────────┤  │
│  │  • auth.controller.js       → Handle registration/login                 │  │
│  │  • business.controller.js   → Business CRUD operations                  │  │
│  │  • document.controller.js   → Document upload/management                │  │
│  │  • publicChat.controller.js → Public chat handling                      │  │
│  │  • team.controller.js       → Team member management                    │  │
│  │  • analytics.controller.js  → Statistics and insights                   │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                              SERVICES                                    │  │
│  ├──────────────────────────────────────────────────────────────────────────┤  │
│  │  • auth.service.js          → JWT generation, password hashing          │  │
│  │  • embedding.service.js     → OpenAI embedding creation                 │  │
│  │  • vector.service.js        → ChromaDB operations                       │  │
│  │  • llm.service.js           → OpenAI GPT chat completions               │  │
│  │  • fileProcessor.service.js → Extract text from files                   │  │
│  │  • business.service.js      → Business logic                            │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                                                                 │
└────────┬────────────────┬────────────────┬────────────────┬─────────────────────┘
         │                │                │                │
         ▼                ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            💾 DATA LAYER                                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐    │
│  │                          🍃 MONGODB                                    │    │
│  │                     (User & Business Data)                             │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │                                                                        │    │
│  │  📦 COLLECTIONS:                                                       │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  users                                                       │    │    │
│  │  │  ├─ _id, email, password (bcrypt), fullName                 │    │    │
│  │  │  ├─ isActive, createdAt, lastLogin                          │    │    │
│  │  │  └─ Indexes: { email: 1 } unique                            │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  businesses                                                  │    │    │
│  │  │  ├─ _id, businessName, businessSlug                          │    │    │
│  │  │  ├─ businessType, industry, description                      │    │    │
│  │  │  ├─ contact info (phone, email, address)                     │    │    │
│  │  │  ├─ branding (logo, primaryColor)                            │    │    │
│  │  │  ├─ chatSettings { welcomeMessage, isPublic, rateLimit }     │    │    │
│  │  │  ├─ createdBy, createdAt, isActive                           │    │    │
│  │  │  └─ Indexes: { businessSlug: 1 } unique                      │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  business_members                                            │    │    │
│  │  │  ├─ _id, userId (ref), businessId (ref)                      │    │    │
│  │  │  ├─ role (owner/admin/manager/staff)                         │    │    │
│  │  │  ├─ permissions { canUpload, canDelete, canManage... }       │    │    │
│  │  │  ├─ joinedAt, status                                         │    │    │
│  │  │  └─ Indexes: { userId: 1, businessId: 1 } unique             │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  documents                                                   │    │    │
│  │  │  ├─ _id, businessId (ref)                                    │    │    │
│  │  │  ├─ filename, originalName, fileType, fileSize               │    │    │
│  │  │  ├─ uploadedBy (ref), uploadedAt                             │    │    │
│  │  │  ├─ chromaCollectionId, chromaIds[]                          │    │    │
│  │  │  ├─ status (processing/completed/failed)                     │    │    │
│  │  │  └─ Indexes: { businessId: 1 }, { uploadedAt: -1 }           │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  public_chats                                                │    │    │
│  │  │  ├─ _id, businessId (ref)                                    │    │    │
│  │  │  ├─ sessionId, ipAddress (hashed), userAgent                 │    │    │
│  │  │  ├─ question, answer, sources[], confidence                  │    │    │
│  │  │  ├─ responseTime, createdAt                                  │    │    │
│  │  │  └─ Indexes: { businessId: 1 }, { createdAt: -1 }            │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  └────────────────────────────────────────────────────────────────────────┘    │
│                                                                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐    │
│  │                          🔷 CHROMADB                                   │    │
│  │                    (Vector Embeddings Storage)                         │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │                                                                        │    │
│  │  📦 COLLECTIONS (One per Business):                                   │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  business_507f1f77bcf86cd799439011                           │    │    │
│  │  │  ├─ id: "doc1_chunk1"                                        │    │    │
│  │  │  ├─ embedding: [0.234, -0.123, 0.567, ... ] (1536 dims)     │    │    │
│  │  │  ├─ document: "We're open Monday-Friday 9am-5pm..."          │    │    │
│  │  │  └─ metadata: {                                              │    │    │
│  │  │      businessId, documentId, filename,                       │    │    │
│  │  │      fileType, uploadedAt, chunkIndex                        │    │    │
│  │  │    }                                                          │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  ┌──────────────────────────────────────────────────────────────┐    │    │
│  │  │  business_507f191e810c19729de860ea                           │    │    │
│  │  │  └─ (Another business's documents)                           │    │    │
│  │  └──────────────────────────────────────────────────────────────┘    │    │
│  │                                                                        │    │
│  │  🔍 OPERATIONS:                                                        │    │
│  │  • add() - Store document chunks with embeddings                      │    │
│  │  • query() - Semantic similarity search                               │    │
│  │  • delete() - Remove document chunks                                  │    │
│  │  • get() - Retrieve specific chunks                                   │    │
│  │                                                                        │    │
│  └────────────────────────────────────────────────────────────────────────┘    │
│                                                                                 │
└─────────────────────────────────┬───────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        🤖 EXTERNAL AI SERVICES                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐    │
│  │                          OPENAI API                                    │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │                                                                        │    │
│  │  📌 EMBEDDINGS API                                                     │    │
│  │  Endpoint: https://api.openai.com/v1/embeddings                       │    │
│  │  Model: text-embedding-3-small                                        │    │
│  │  ├─ Input: Text string                                                │    │
│  │  ├─ Output: Array of 1536 numbers (vector)                            │    │
│  │  ├─ Cost: ~$0.00002 per embedding                                     │    │
│  │  └─ Use: Convert text to semantic vectors for search                  │    │
│  │                                                                        │    │
│  │  🤖 CHAT COMPLETIONS API                                              │    │
│  │  Endpoint: https://api.openai.com/v1/chat/completions                 │    │
│  │  Model: gpt-3.5-turbo                                                 │    │
│  │  ├─ Input: System prompt + User question + Context                    │    │
│  │  ├─ Output: Natural language answer                                   │    │
│  │  ├─ Cost: ~$0.0005 per question                                       │    │
│  │  └─ Use: Generate intelligent answers based on context                │    │
│  │                                                                        │    │
│  └────────────────────────────────────────────────────────────────────────┘    │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Complete Data Flow Diagrams

### Flow 1: Business Registration & Document Upload

```
┌──────────────────────────────────────────────────────────────────────────┐
│                    BUSINESS REGISTRATION FLOW                            │
└──────────────────────────────────────────────────────────────────────────┘

Business Owner
    │
    │ 1. POST /api/business/register
    │    { email, password, businessName, ... }
    ▼
┌────────────────────────────────┐
│  🔒 SECURITY CHECKS            │
│  ├─ Rate limit (5/15min)       │
│  ├─ Email format validation    │
│  ├─ Password strength check    │
│  └─ Input sanitization         │
└────────────┬───────────────────┘
             │ ✓ Passed
             ▼
┌────────────────────────────────┐
│  🔐 AUTHENTICATION SERVICE     │
│  ├─ Hash password (bcrypt)     │
│  ├─ Generate user ID           │
│  └─ Generate business ID       │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  💾 SAVE TO MONGODB            │
│  ├─ Create user record         │
│  ├─ Create business record     │
│  └─ Create member record       │
│      (owner role)              │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  🔷 INITIALIZE CHROMADB        │
│  └─ Create collection:         │
│      "business_[businessId]"   │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  🎫 GENERATE JWT TOKEN         │
│  └─ Include: userId,           │
│      businessId, role          │
└────────────┬───────────────────┘
             │
             ▼
    Return to Business Owner:
    { token, user, business }


┌──────────────────────────────────────────────────────────────────────────┐
│                     DOCUMENT UPLOAD FLOW                                 │
└──────────────────────────────────────────────────────────────────────────┘

Business User
    │
    │ 2. POST /api/business/:id/documents/upload
    │    Authorization: Bearer [token]
    │    Content-Type: multipart/form-data
    │    File: services.pdf
    ▼
┌────────────────────────────────┐
│  🔒 SECURITY CHECKS            │
│  ├─ JWT verification           │
│  ├─ Business access check      │
│  ├─ Permission check           │
│  ├─ File type validation       │
│  │   (PDF/TXT/DOCX/CSV/MD/JSON)│
│  ├─ File size check (<10MB)    │
│  ├─ MIME type verification     │
│  └─ Rate limit (5 uploads/hour)│
└────────────┬───────────────────┘
             │ ✓ Passed
             ▼
┌────────────────────────────────┐
│  📁 FILE PROCESSING            │
│  ├─ Save to /uploads temp      │
│  ├─ Extract text content       │
│  │   • PDF → pdf-parse         │
│  │   • DOCX → mammoth          │
│  │   • TXT → fs.readFile       │
│  │   • CSV → csv-parser        │
│  └─ Validate text extracted    │
└────────────┬───────────────────┘
             │ Text: "We're open 9-5..."
             ▼
┌────────────────────────────────┐
│  💾 SAVE METADATA TO MONGODB   │
│  └─ Create document record     │
│      status: "processing"      │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  🤖 CREATE EMBEDDING           │
│  ├─ Call OpenAI API            │
│  │   POST /v1/embeddings       │
│  │   { input: text }           │
│  ├─ Receive 1536-dim vector    │
│  └─ Cost: $0.00002             │
└────────────┬───────────────────┘
             │ embedding: [0.234, -0.123, ...]
             ▼
┌────────────────────────────────┐
│  🔷 STORE IN CHROMADB          │
│  ├─ Get business collection    │
│  ├─ Add document:              │
│  │   { id, embedding,          │
│  │     document: text,         │
│  │     metadata }              │
│  └─ Cost: FREE                 │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  💾 UPDATE MONGODB             │
│  └─ Update document:           │
│      status: "completed"       │
│      chromaIds: [...]          │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  🗑️ CLEANUP                    │
│  └─ Delete temp file           │
│      from /uploads             │
└────────────┬───────────────────┘
             │
             ▼
    Return to Business User:
    { success, document }
```

### Flow 2: Public Customer Chat (RAG)

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        PUBLIC CHAT FLOW (RAG)                            │
└──────────────────────────────────────────────────────────────────────────┘

Customer (Anonymous)
    │
    │ 3. POST /api/public/luxury-salon/chat
    │    { question: "How much is a haircut?",
    │      sessionId: "sess_xyz123" }
    ▼
┌────────────────────────────────┐
│  🔒 SECURITY CHECKS            │
│  ├─ Rate limit (10/hour by IP)│
│  ├─ Input validation           │
│  │   • Max 500 chars           │
│  │   • Non-empty               │
│  ├─ XSS sanitization           │
│  └─ Business exists & active   │
└────────────┬───────────────────┘
             │ ✓ Passed
             ▼
┌────────────────────────────────┐
│  🤖 CREATE QUESTION EMBEDDING  │
│  ├─ Call OpenAI API            │
│  │   POST /v1/embeddings       │
│  │   { input: question }       │
│  ├─ Receive vector             │
│  └─ Cost: $0.00002             │
└────────────┬───────────────────┘
             │ queryEmbedding: [0.231, -0.119, ...]
             ▼
┌────────────────────────────────┐
│  🔷 SEARCH CHROMADB (RAG!)     │
│  ├─ Get business collection    │
│  ├─ Query similar vectors      │
│  │   collection.query({        │
│  │     queryEmbeddings,        │
│  │     nResults: 3             │
│  │   })                        │
│  ├─ Cosine similarity search   │
│  └─ Return top 3 matches       │
└────────────┬───────────────────┘
             │ Found:
             │ 1. "Haircut: $50..." (score: 0.95)
             │ 2. "Services include..." (score: 0.82)
             │ 3. "We're open..." (score: 0.65)
             ▼
┌────────────────────────────────┐
│  📝 BUILD PROMPT               │
│  └─ Construct:                 │
│      System: "You are helpful  │
│               assistant for    │
│               Luxury Salon"    │
│      Context: [Retrieved docs] │
│      Question: [User question] │
└────────────┬───────────────────┘
             │
             ▼
┌────────────────────────────────┐
│  🤖 CALL OPENAI GPT            │
│  ├─ POST /v1/chat/completions  │
│  ├─ Model: gpt-3.5-turbo       │
│  ├─ Send prompt with context   │
│  ├─ Receive answer             │
│  └─ Cost: $0.0005              │
└────────────┬───────────────────┘
             │ answer: "Our haircut service costs $50..."
             ▼
┌────────────────────────────────┐
│  💾 LOG CHAT                   │
│  └─ Save to public_chats       │
│      collection in MongoDB     │
│      (for analytics)           │
└────────────┬───────────────────┘
             │
             ▼
    Return to Customer:
    {
      answer: "Our haircut...",
      sources: ["services.pdf"],
      confidence: 0.95
    }
    
    Total Cost: ~$0.00052
    Total Time: ~1-2 seconds
```

---

## 🔐 Security Architecture Map

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         SECURITY LAYERS & MEASURES                              │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 1: NETWORK SECURITY                                                       │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  🌐 HTTPS/TLS Encryption                                                        │
│  ├─ All traffic encrypted                                                       │
│  ├─ SSL certificates (Let's Encrypt)                                            │
│  └─ Secure WebSocket connections                                                │
│                                                                                 │
│  🔒 CORS (Cross-Origin Resource Sharing)                                        │
│  ├─ Whitelist allowed origins                                                   │
│  ├─ Control methods (GET, POST, DELETE)                                         │
│  ├─ Credential handling                                                         │
│  └─ Preflight request validation                                                │
│                                                                                 │
│  🛡️ Helmet.js (Security Headers)                                                │
│  ├─ X-Frame-Options: DENY                                                       │
│  ├─ X-Content-Type-Options: nosniff                                             │
│  ├─ X-XSS-Protection: 1; mode=block                                             │
│  ├─ Strict-Transport-Security                                                   │
│  └─ Content-Security-Policy                                                     │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 2: RATE LIMITING & DDOS PROTECTION                                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ⏱️ General API Rate Limit                                                      │
│  └─ 100 requests / 15 minutes per IP                                            │
│                                                                                 │
│  💬 Public Chat Rate Limit                                                      │
│  └─ 10 questions / hour per IP address                                          │
│                                                                                 │
│  🔐 Auth Endpoints Rate Limit (Brute Force Protection)                          │
│  ├─ Login: 5 attempts / 15 minutes                                              │
│  ├─ Register: 3 attempts / hour                                                 │
│  └─ Password reset: 3 attempts / hour                                           │
│                                                                                 │
│  📤 Upload Rate Limit                                                           │
│  └─ 5 uploads / hour per user                                                   │
│                                                                                 │
│  🚫 Response on Limit Exceeded                                                  │
│  └─ HTTP 429 Too Many Requests                                                  │
│      { error: "Rate limit exceeded", retryAfter: 900 }                          │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 3: AUTHENTICATION & AUTHORIZATION                                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  🎫 JWT (JSON Web Tokens)                                                       │
│  ├─ Algorithm: HS256                                                            │
│  ├─ Expiration: 7 days                                                          │
│  ├─ Payload: { userId, businessId, role, permissions }                          │
│  ├─ Secret: Strong random string (env variable)                                 │
│  └─ Verification on every protected route                                       │
│                                                                                 │
│  🔑 Password Security                                                           │
│  ├─ Hashing: bcrypt with salt rounds = 12                                       │
│  ├─ Minimum requirements:                                                       │
│  │   • 8+ characters                                                            │
│  │   • Uppercase + lowercase                                                    │
│  │   • At least 1 number                                                        │
│  │   • At least 1 special char (optional)                                       │
│  └─ Never store plain text passwords                                            │
│                                                                                 │
│  👤 Session Management                                                          │
│  ├─ Public users: sessionId (UUID)                                              │
│  ├─ Business users: JWT token                                                   │
│  └─ Token refresh mechanism (optional)                                          │
│                                                                                 │
│  🔐 Permission-Based Access Control (PBAC)                                      │
│  ├─ Check user role (owner/admin/manager/staff)                                 │
│  ├─ Verify specific permissions:                                                │
│  │   • canUploadDocuments                                                       │
│  │   • canDeleteDocuments                                                       │
│  │   • canManageTeam                                                            │
│  │   • canViewAnalytics                                                         │
│  │   • canManageSettings                                                        │
│  └─ Deny if insufficient permissions                                            │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 4: INPUT VALIDATION & SANITIZATION                                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ✅ Request Validation (express-validator)                                      │
│  ├─ Email format validation                                                     │
│  ├─ Password strength validation                                                │
│  ├─ Required fields check                                                       │
│  ├─ Type validation (string/number/boolean)                                     │
│  ├─ Length constraints                                                          │
│  └─ Custom validation rules                                                     │
│                                                                                 │
│  🧹 Input Sanitization                                                          │
│  ├─ Trim whitespace                                                             │
│  ├─ Escape HTML entities                                                        │
│  ├─ Remove script tags                                                          │
│  └─ Normalize email addresses                                                   │
│                                                                                 │
│  💉 NoSQL Injection Prevention (express-mongo-sanitize)                         │
│  ├─ Remove $ and . from input                                                   │
│  ├─ Prevent MongoDB operator injection                                          │
│  └─ Example blocked: { "$gt": "" }                                              │
│                                                                                 │
│  🔪 XSS Prevention (xss-clean)                                                  │
│  ├─ Clean user input from malicious scripts                                     │
│  ├─ Remove <script> tags                                                        │
│  ├─ Sanitize HTML attributes                                                    │
│  └─ Example blocked: <img src=x onerror="alert('XSS')">                         │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 5: FILE UPLOAD SECURITY                                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  📄 File Type Validation (Multer)                                               │
│  ├─ Allowed extensions: .pdf .txt .docx .csv .md .json                          │
│  ├─ MIME type verification:                                                     │
│  │   • application/pdf                                                          │
│  │   • text/plain                                                               │
│  │   • application/vnd.openxml... (docx)                                        │
│  │   • text/csv                                                                 │
│  │   • text/markdown                                                            │
│  │   • application/json                                                         │
│  ├─ Double check: MIME + extension match                                        │
│  └─ Reject if mismatch (prevent spoofing)                                       │
│                                                                                 │
│  📏 File Size Limits                                                            │
│  ├─ Maximum: 10MB per file                                                      │
│  ├─ Total upload limit per business (optional)                                  │
│  └─ HTTP 413 Payload Too Large if exceeded                                      │
│                                                                                 │
│  🗂️ File Storage Security                                                       │
│  ├─ Temporary storage in /uploads                                               │
│  ├─ Generate random filenames (prevent path traversal)                          │
│  ├─ Delete temp files after processing                                          │
│  ├─ No execution permissions on upload directory                                │
│  └─ Optional: Scan with antivirus (ClamAV)                                      │
│                                                                                 │
│  🚫 Blocked File Types                                                          │
│  └─ .exe .sh .bat .cmd .scr .dll .jar .zip                                      │
│      (Executables and potentially harmful files)                                │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 6: DATA ISOLATION & PRIVACY                                               │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  🏢 Business Data Isolation                                                     │
│  ├─ Every query filtered by businessId                                          │
│  ├─ Separate ChromaDB collections per business                                  │
│  ├─ Validate user belongs to business before access                             │
│  └─ Cross-business access = immediate 403 Forbidden                             │
│                                                                                 │
│  🔒 Database Security                                                           │
│  ├─ MongoDB authentication enabled                                              │
│  ├─ Least privilege access (app user can't drop DB)                             │
│  ├─ IP whitelist for database access                                            │
│  └─ Encrypted connections (TLS)                                                 │
│                                                                                 │
│  🕵️ Customer Privacy (Public Chat)                                              │
│  ├─ No PII collection                                                           │
│  ├─ IP addresses hashed before storage                                          │
│  ├─ SessionId = random UUID (not trackable)                                     │
│  ├─ No email/name required                                                      │
│  └─ GDPR compliant (anonymous by design)                                        │
│                                                                                 │
│  🔐 Sensitive Data Handling                                                     │
│  ├─ Passwords: bcrypt hashed, never logged                                      │
│  ├─ JWT secrets: environment variables                                          │
│  ├─ OpenAI keys: environment variables, never exposed                           │
│  └─ Credit cards: Not stored (use Stripe if needed)                             │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 7: LOGGING & MONITORING                                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  📝 Security Event Logging                                                      │
│  ├─ Failed login attempts                                                       │
│  ├─ Rate limit violations                                                       │
│  ├─ Permission denied errors                                                    │
│  ├─ File upload rejections                                                      │
│  ├─ Cross-business access attempts                                              │
│  └─ Suspicious patterns (multiple IPs same user)                                │
│                                                                                 │
│  🚨 Alert System (Future)                                                       │
│  ├─ Email on multiple failed logins                                             │
│  ├─ Slack notification on security events                                       │
│  └─ Dashboard for security metrics                                              │
│                                                                                 │
│  📊 Audit Trail                                                                 │
│  ├─ Document uploads/deletes                                                    │
│  ├─ Team member additions/removals                                              │
│  ├─ Permission changes                                                          │
│  └─ Settings modifications                                                      │
│                                                                                 │
│  🔍 What NOT to Log                                                             │
│  ├─ ❌ Passwords (hashed or plain)                                              │
│  ├─ ❌ JWT tokens                                                                │
│  ├─ ❌ API keys                                                                  │
│  ├─ ❌ Full credit card numbers                                                  │
│  └─ ❌ Personal identifiable information (PII)                                   │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 8: ERROR HANDLING                                                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ✅ Production Error Responses                                                  │
│  ├─ Generic messages (don't expose internals)                                   │
│  ├─ Example: "An error occurred" vs "SQL syntax error..."                       │
│  └─ Log details server-side, show generic to user                               │
│                                                                                 │
│  ❌ Development Error Responses                                                 │
│  └─ Detailed stack traces (only in NODE_ENV=development)                        │
│                                                                                 │
│  🔒 Security Error Codes                                                        │
│  ├─ 401 Unauthorized - Missing/invalid auth                                     │
│  ├─ 403 Forbidden - Insufficient permissions                                    │
│  ├─ 429 Too Many Requests - Rate limit exceeded                                 │
│  └─ 500 Internal Server Error - Generic failure                                 │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 📊 Performance & Scalability Map

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    PERFORMANCE OPTIMIZATION POINTS                              │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ⚡ Database Optimization                                                        │
│  ├─ MongoDB Indexes:                                                            │
│  │   • users.email (unique)                                                     │
│  │   • businesses.businessSlug (unique)                                         │
│  │   • business_members.userId + businessId (compound, unique)                  │
│  │   • documents.businessId                                                     │
│  │   • public_chats.businessId + createdAt                                      │
│  ├─ Connection pooling (max 10 connections)                                     │
│  └─ Query projection (select only needed fields)                                │
│                                                                                 │
│  🔷 ChromaDB Optimization                                                       │
│  ├─ Separate collections per business (isolation + speed)                       │
│  ├─ Batch operations when possible                                              │
│  └─ Local storage (no network latency)                                          │
│                                                                                 │
│  💾 Caching Strategy (Optional - Phase 2)                                       │
│  ├─ Redis for frequent queries                                                  │
│  ├─ Cache business info (1 hour TTL)                                            │
│  ├─ Cache common questions/answers (30 min TTL)                                 │
│  └─ Invalidate on document upload                                               │
│                                                                                 │
│  🗜️ Compression                                                                 │
│  ├─ Gzip middleware for responses                                               │
│  └─ Reduce payload sizes by 70-80%                                              │
│                                                                                 │
│  📊 Response Time Targets                                                       │
│  ├─ Public chat: < 2 seconds                                                    │
│  ├─ Document upload: < 10 seconds                                               │
│  ├─ Auth endpoints: < 500ms                                                     │
│  └─ List operations: < 300ms                                                    │
│                                                                                 │
│  📈 Scalability Strategy                                                        │
│  ├─ Horizontal scaling: Multiple API instances                                  │
│  ├─ Load balancer (NGINX/AWS ALB)                                               │
│  ├─ Stateless design (no in-memory sessions)                                    │
│  └─ Database sharding (if needed for millions of businesses)                    │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 💰 Cost Breakdown Map

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          COST ANALYSIS                                          │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  💵 MONTHLY COSTS (1 Business, 1,000 Customer Chats)                            │
│  ┌────────────────────────────────────────────────────────────────────────┐    │
│  │  Service              │  Usage          │  Cost        │  Notes         │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │  MongoDB Atlas        │  < 512MB        │  $0.00       │  Free tier    │    │
│  │  ChromaDB             │  Local          │  $0.00       │  Self-hosted  │    │
│  │  OpenAI Embeddings    │  1,000 calls    │  $0.02       │  Upload+query │    │
│  │  OpenAI GPT-3.5       │  1,000 calls    │  $0.50       │  Answers      │    │
│  │  Hosting (Railway)    │  500 hrs        │  $0.00       │  Free tier    │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │  TOTAL PER BUSINESS   │                 │  $0.52/mo    │               │    │
│  └────────────────────────────────────────────────────────────────────────┘    │
│                                                                                 │
│  💰 SCALING COSTS (100 Businesses, 100,000 Total Chats)                         │
│  ┌────────────────────────────────────────────────────────────────────────┐    │
│  │  Service              │  Usage          │  Cost        │  Notes         │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │  MongoDB Atlas        │  ~500MB         │  $0.00       │  Still free!  │    │
│  │  ChromaDB             │  ~2GB storage   │  $0.00       │  Local SSD    │    │
│  │  OpenAI Embeddings    │  100k calls     │  $2.00       │  Scaled       │    │
│  │  OpenAI GPT-3.5       │  100k calls     │  $50.00      │  Main cost    │    │
│  │  Hosting (Render)     │  Upgraded       │  $7.00       │  Paid tier    │    │
│  ├────────────────────────────────────────────────────────────────────────┤    │
│  │  TOTAL                │                 │  $59/mo      │  ~$0.59/biz   │    │
│  └────────────────────────────────────────────────────────────────────────┘    │
│                                                                                 │
│  🎯 COST OPTIMIZATION TIPS                                                      │
│  ├─ Use GPT-3.5-turbo (10x cheaper than GPT-4)                                  │
│  ├─ Cache frequent questions (reduce API calls)                                 │
│  ├─ Batch embeddings when possible                                              │
│  ├─ Set max_tokens to reasonable limit (300-500)                                │
│  └─ Monitor usage with OpenAI dashboard                                         │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        PRODUCTION DEPLOYMENT                                    │
└─────────────────────────────────────────────────────────────────────────────────┘

                              ┌──────────────┐
                              │   DOMAIN     │
                              │  DNS (A/AAAA)│
                              └──────┬───────┘
                                     │
                                     ▼
                         ┌────────────────────────┐
                         │   LOAD BALANCER        │
                         │   (NGINX / AWS ALB)    │
                         │   ├─ SSL Termination   │
                         │   ├─ Rate limiting     │
                         │   └─ Health checks     │
                         └─────────┬──────────────┘
                                   │
                    ┌──────────────┼──────────────┐
                    ▼              ▼              ▼
          ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
          │  API Server  │ │  API Server  │ │  API Server  │
          │  Instance 1  │ │  Instance 2  │ │  Instance N  │
          │              │ │              │ │              │
          │  Express.js  │ │  Express.js  │ │  Express.js  │
          │  Node.js     │ │  Node.js     │ │  Node.js     │
          │  ChromaDB    │ │  ChromaDB    │ │  ChromaDB    │
          └──────┬───────┘ └──────┬───────┘ └──────┬───────┘
                 │                │                │
                 └────────────────┼────────────────┘
                                  │
                    ┌─────────────┼─────────────┐
                    ▼             ▼             ▼
          ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
          │   MongoDB    │  │   OpenAI     │  │   Logging    │
          │   Atlas      │  │   API        │  │   Service    │
          │   (Cloud)    │  │              │  │   (Optional) │
          └──────────────┘  └──────────────┘  └──────────────┘


📦 HOSTING OPTIONS (Recommended):

Option 1: Railway (Easiest)
├─ Auto-deploy from GitHub
├─ Free SSL certificates
├─ MongoDB add-on available
├─ $0-$5/month to start
└─ Good for MVP

Option 2: Render
├─ Similar to Railway
├─ Better free tier (750hrs/mo)
├─ PostgreSQL + MongoDB available
└─ Easy scaling

Option 3: AWS (Advanced)
├─ EC2 instances
├─ RDS/DocumentDB for MongoDB
├─ ALB for load balancing
├─ Most flexible
└─ Higher cost & complexity

Option 4: DigitalOcean
├─ Droplets (VMs)
├─ Managed MongoDB
├─ Load Balancer
└─ Mid-range pricing
```

---

## 📁 Complete File Structure

```
business-ai-assistant/
│
├── src/
│   │
│   ├── config/
│   │   ├── database.js          # MongoDB connection & setup
│   │   ├── chromadb.js          # ChromaDB client initialization
│   │   ├── openai.js            # OpenAI client setup
│   │   └── constants.js         # App constants (roles, file types, etc.)
│   │
│   ├── models/                  # Mongoose schemas
│   │   ├── User.js              # User model
│   │   ├── Business.js          # Business model
│   │   ├── BusinessMember.js    # Junction table for users-businesses
│   │   ├── Document.js          # Document metadata model
│   │   └── PublicChat.js        # Public chat logs model
│   │
│   ├── middleware/
│   │   ├── auth.js              # JWT verification
│   │   ├── businessAccess.js    # Check business membership
│   │   ├── permissions.js       # Check specific permissions
│   │   ├── validation.js        # Input validation middleware
│   │   ├── fileUpload.js        # Multer configuration
│   │   ├── rateLimiter.js       # Rate limiting configs
│   │   ├── errorHandler.js      # Global error handler
│   │   └── logger.js            # Request logging middleware
│   │
│   ├── routes/
│   │   ├── public.routes.js     # Public chat routes (no auth)
│   │   ├── auth.routes.js       # Business registration/login
│   │   ├── business.routes.js   # Business management
│   │   ├── document.routes.js   # Document operations
│   │   ├── team.routes.js       # Team member management
│   │   ├── analytics.routes.js  # Analytics and stats
│   │   └── health.routes.js     # Health check endpoint
│   │
│   ├── controllers/             # Route handlers
│   │   ├── auth.controller.js
│   │   ├── business.controller.js
│   │   ├── document.controller.js
│   │   ├── publicChat.controller.js
│   │   ├── team.controller.js
│   │   └── analytics.controller.js
│   │
│   ├── services/                # Business logic
│   │   ├── auth.service.js      # JWT, password hashing
│   │   ├── embedding.service.js # OpenAI embeddings
│   │   ├── vector.service.js    # ChromaDB operations
│   │   ├── llm.service.js       # OpenAI GPT operations
│   │   ├── fileProcessor.service.js  # Text extraction from files
│   │   ├── business.service.js  # Business operations
│   │   ├── chat.service.js      # RAG chat logic
│   │   └── analytics.service.js # Stats calculations
│   │
│   ├── utils/
│   │   ├── helpers.js           # Utility functions
│   │   ├── validators.js        # Custom validators
│   │   ├── roles.js             # Role definitions & permissions
│   │   └── logger.js            # Winston logger setup
│   │
│   └── types/                   # TypeScript types (if using TS)
│       └── index.d.ts
│
├── uploads/                     # Temporary file storage (gitignored)
├── chroma_data/                 # ChromaDB storage (gitignored)
├── logs/                        # Application logs (gitignored)
│
├── tests/                       # Test files
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── .env                         # Environment variables (gitignored)
├── .env.example                 # Example env file
├── .gitignore
├── package.json
├── package-lock.json
├── server.js                    # Main entry point
├── README.md
└── ARCHITECTURE.md              # This document!
```

---

## 🎯 Quick Reference: Key Endpoints

```
PUBLIC ENDPOINTS (No Authentication)
├─ GET  /api/public/:businessSlug              → Get business info
└─ POST /api/public/:businessSlug/chat         → Ask question (RAG)

AUTHENTICATION
├─ POST /api/business/register                 → Register business + owner
└─ POST /api/business/login                    → Login

BUSINESS MANAGEMENT (JWT Required)
├─ GET    /api/business/:businessId            → Get business details
├─ PATCH  /api/business/:businessId/settings   → Update settings
└─ DELETE /api/business/:businessId            → Delete business

DOCUMENTS (JWT + Permissions Required)
├─ POST   /api/business/:businessId/documents/upload  → Upload doc
├─ GET    /api/business/:businessId/documents         → List docs
├─ GET    /api/business/:businessId/documents/:docId  → Get doc details
└─ DELETE /api/business/:businessId/documents/:docId  → Delete doc

TEAM MANAGEMENT (JWT + Admin Required)
├─ POST   /api/business/:businessId/team/invite    → Invite member
├─ GET    /api/business/:businessId/team           → List members
├─ PATCH  /api/business/:businessId/team/:userId   → Update role
└─ DELETE /api/business/:businessId/team/:userId   → Remove member

ANALYTICS (JWT Required)
└─ GET /api/business/:businessId/analytics     → Get chat stats

HEALTH
└─ GET /api/health                             → System status
```

---

## 📋 Environment Variables Reference

```bash
# Server Configuration
NODE_ENV=production                    # development | production
PORT=3000                              # API port
API_URL=https://api.yourdomain.com     # Public API URL

# Database
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/dbname
MONGODB_MAX_POOL_SIZE=10

# JWT
JWT_SECRET=your-super-secret-key-min-32-chars-long
JWT_EXPIRE=7d

# OpenAI
OPENAI_API_KEY=sk-your-openai-api-key-here
OPENAI_ORG_ID=org-your-org-id          # Optional

# Security
BCRYPT_ROUNDS=12
ALLOWED_ORIGINS=https://yourdomain.com,https://admin.yourdomain.com

# File Upload
MAX_FILE_SIZE=10485760                 # 10MB in bytes
UPLOAD_PATH=./uploads
ALLOWED_FILE_TYPES=pdf,txt,docx,csv,md,json

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000            # 15 minutes
RATE_LIMIT_MAX_REQUESTS=100
PUBLIC_CHAT_RATE_LIMIT=10              # Per hour per IP

# Logging
LOG_LEVEL=info                         # error | warn | info | debug
LOG_FILE=./logs/app.log

# Feature Flags (Optional)
ENABLE_ANALYTICS=true
ENABLE_EMAIL_INVITES=false
ENABLE_CACHING=false
```

---

## 🎓 Summary

This system is:
- ✅ **Secure** - Multiple layers of security
- ✅ **Scalable** - Can handle growth from 1 to 10,000+ businesses
- ✅ **Cost-effective** - ~$0.50/business/month for 1,000 chats
- ✅ **Privacy-focused** - Anonymous customer chats, GDPR compliant
- ✅ **Developer-friendly** - Clear structure, well-documented
- ✅ **Production-ready** - Error handling, logging, monitoring

**Total Technologies Used:** 20+
**Total API Endpoints:** 15+
**Security Measures:** 30+
**Estimated Response Time:** 1-2 seconds per chat
**Estimated Uptime:** 99.9%

---

**Last Updated:** December 29, 2024
**Version:** 1.0
**Author:** System Architecture Documentation
